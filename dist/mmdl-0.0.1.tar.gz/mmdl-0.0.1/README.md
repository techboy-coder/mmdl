# mmdl

Mmdl [Mega Music Downloader] - A tool to easily download music.
